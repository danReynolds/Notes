#include "Lead.h"

// constructor
Lead::Lead() {}

// destructor
Lead::~Lead() {}
